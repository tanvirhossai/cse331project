#include <reg51.h>
#include <stdio.h>
sbit er=p2^7;
sbit ey=p2^6;
sbit eg=p2^5;
// East signals connections declaration//
sbit wr=p2^4;
sbit wy=p2^3;
sbit wg=p2^2;
// west signals connections declaration//
sbit nr=p2^1;
sbit ny=p2^0;
sbit ng=p3^0;
// North signals connections declaration//
sbit sr=p3^1;
sbit sy=p3^2;
sbit sg=p3^3;
// South signals connections declaration//
void delay(unsigned int);
void main()
{
p2=p3=0x00;
while(1)
{
eg=wr=sr=nr=1;
delay(30);
eg=0;nr=0; 
ey=ny=1;
delay(10);
ey=ny=0;
er=ng=1;
delay(30);
ng=0;wr=0;
ny=wy=1;
delay(10);
ny=wy=0;
nr=wg=1;
delay(30);
wr=sr=0;
wy=sy=1;
delay(10);
wy=sy=0;
wr=sg=1;
delay(30);
sg=er=0;
sy=ey=1;
delay=(10);
sy=ey=0;
}
}

void delay(unsigned int v)
{
unsigned int x,y;
for(x=0;x<v;x++)
{
for(y=0;y<25000;y++)
}
}